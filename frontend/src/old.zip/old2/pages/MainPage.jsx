import React, { useState, useEffect } from 'react';
import {
    AppShell, ScrollArea, Stack,
    useMantineColorScheme,
} from '@mantine/core';

// 스타일 imports
import '../styles/animation.css';
import CustomLoader from "@/components/CustomLoader.jsx";
import Navbar from "@/components/Navbar.jsx";
import Header from "@/components/Header.jsx";
import {Outlet} from "react-router-dom";
import MobileDrawer from "@/components/MobileDrawer.jsx";
import {navigationItems, popularTags} from "@/constants/data.js";

const MainPageLayout = () => {


    const [drawerOpened, setDrawerOpened] = useState(false);
    const [loading, setLoading] = useState(true);
    const [progress, setProgress] = useState(0);
    const [isLoggedIn, setIsLoggedIn] = useState(true);
    const { colorScheme,toggleColorScheme } = useMantineColorScheme();
    const dark = colorScheme === 'dark';

    // 로딩 효과 시뮬레이션
    // useEffect(() => {
    //     const timer = setInterval(() => {
    //         setProgress((prevProgress) => {
    //             if (prevProgress >= 100) {
    //                 clearInterval(timer);
    //                 setTimeout(() => setLoading(false), 500);
    //                 return 100;
    //             }
    //             return prevProgress + Math.random() * 15;
    //         });
    //     }, 200);
    //
    //     return () => clearInterval(timer);
    // }, []);
    //
    //
    //
    // if (loading) {
    //     return (
    //         <Box
    //             style={{
    //                 height: '100vh',
    //                 background: dark ? '#0d1117' : '#f8fafc',
    //                 overflow: 'hidden',
    //             }}
    //         >
    //             <CustomLoader progress={progress} dark={dark} />
    //         </Box>
    //     );
    // }

    return (
        <AppShell
            header={{height: 60, offset: true}}
            navbar={{
                width: 280,
                breakpoint: 'lg',
                collapsed: {mobile: true},
            }}
            // padding="md"
            style={{
                background: dark ? '#1a1a1a' : '#f8fafc',
            }}
        >
            <Header
                drawerOpened={drawerOpened}
                setDrawerOpened={setDrawerOpened}
                // userProfile={userProfile}
                isLoggedIn={isLoggedIn}
                setIsLoggedIn={setIsLoggedIn}
                toggleColorScheme={toggleColorScheme}
                dark={dark}
            />

            <MobileDrawer
                opened={drawerOpened}
                onClose={() => setDrawerOpened(false)}
                navigationItems={navigationItems}
                popularTags={popularTags}
                // userProfile={userProfile}
                isLoggedIn={isLoggedIn}
                setIsLoggedIn={setIsLoggedIn}
                dark={dark}
            />
            <Navbar
                navigationItems={navigationItems}
                popularTags={popularTags}
                dark={dark}
            />
            <ScrollArea component={AppShell.Main} h={200} scrollbars="y">
                <Outlet context={{
                    loading,
                    dark
                }}/>
            </ScrollArea>
        </AppShell>
    );
};

export default MainPageLayout;