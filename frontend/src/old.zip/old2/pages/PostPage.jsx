import {useOutletContext, useParams} from "react-router-dom";
import {Box, Button, Center, Container, Divider, Group, rem, Stack, Text, Title} from "@mantine/core";
import PostList from "@/components/PostList.jsx";
import {recentPosts} from "@/constants/data.js";
import React from "react";
import {
    IconBookOff,
    IconChevronRight, IconCode, IconCoffee,
    IconEye,
    IconHeart,
    IconMessage,
    IconSparkles,
    IconUsers
} from "@tabler/icons-react";
import PostHeroSection from "@/components/BannerSection.jsx";
import BannerSection from "@/components/BannerSection.jsx";

const PostPage = () => {
    const {category} = useParams();
    const {dark} = useOutletContext();
    // const customStats = [
    //     { icon: IconBookOff, label: '총 게시글', value: '42', color: '#3b82f6' },
    //     { icon: IconUsers, label: '월간 독자', value: '1.2K', color: '#10b981' },
    //     { icon: IconHeart, label: '총 좋아요', value: '350', color: '#ef4444' },
    //     { icon: IconEye, label: '총 조회수', value: '25.6K', color: '#f59e0b' },
    //     { icon: IconMessage, label: '댓글', value: '128', color: '#8b5cf6' },
    //     { icon: IconCode, label: '기술 스택', value: '15+', color: '#06b6d4' },
    // ];

    return (
        <>
            <BannerSection
                variant="simple"
                title=""
                enableTyping={true}
                typingTexts={[
                    "알고리즘",
                    "자료구조",
                    "인사이트",
                    "기본지식"
                ]}
                typingSpeed={150}
                deleteSpeed={75}
                pauseTime={3000}
            />
            <Container size='lg'>

                <Stack gap='xl' mb='xl' mt='xl'>
                    {/* Header Section */}
                    <Group justify="center" gap="xs" mb='md'>
                        <Box style={{ flex: 1 }}>
                            <Center gap="xs" mb="xs">
                                <IconCoffee
                                    size={24}
                                    color={dark ? '#60a5fa' : '#3b82f6'}
                                />
                                <Title
                                    ml={10}
                                    order={2}
                                    size="h1"
                                    style={{
                                        backgroundImage: dark
                                            ? 'linear-gradient(135deg, var(--mantine-color-white) 0%, var(--mantine-color-gray-3) 100%)'
                                            : 'linear-gradient(135deg, var(--mantine-color-gray-7) 0%, var(--mantine-color-gray-8) 100%)',
                                        backgroundClip: 'text',
                                        WebkitBackgroundClip: 'text',
                                        color: 'transparent',
                                        fontWeight: 800,
                                        fontSize: rem(32),
                                        letterSpacing: '-0.02em',
                                    }}
                                >
                                    {category.toUpperCase()}
                                </Title>
                            </Center>
                            <Center>
                                <Text
                                    size="lg"
                                    c={dark ? 'gray.4' : 'gray.6'}
                                    style={{ maxWidth: '600px' }}
                                >
                                    공부하는 내용 정리
                                </Text>
                            </Center>

                        </Box>

                        <Button
                            variant="gradient"
                            gradient={{ from: 'blue', to: 'cyan', deg: 45 }}
                            size="md"
                            radius="md"
                            leftSection={
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                                    <path d="M12 5v14M5 12h14"/>
                                </svg>
                            }
                            style={{
                                boxShadow: '0 4px 12px rgba(34, 139, 230, 0.4)',
                                transition: 'all 0.2s ease',
                                '&:hover': {
                                    transform: 'translateY(-2px)',
                                    boxShadow: '0 6px 20px rgba(34, 139, 230, 0.5)',
                                }
                            }}
                            onClick={() => {
                                // 포스팅 페이지로 이동하거나 모달 열기
                                console.log('포스트 작성 버튼 클릭');
                            }}
                        >
                            새 포스트 작성
                        </Button>
                    </Group>
                </Stack>
            </Container>
            <PostList posts={recentPosts} dark={dark} />
        </>
    )
}

export default PostPage